putchar(getchar());
0
