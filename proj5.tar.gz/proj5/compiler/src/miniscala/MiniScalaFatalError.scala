package miniscala

case class MiniScalaFatalError(msg: String) extends Exception(msg)
